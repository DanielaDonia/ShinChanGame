gdjs.Level2Code = {};
gdjs.Level2Code.GDPlayerObjects1= [];
gdjs.Level2Code.GDPlayerObjects2= [];
gdjs.Level2Code.GDPlayerObjects3= [];
gdjs.Level2Code.GDPlayerObjects4= [];
gdjs.Level2Code.GDPlayerObjects5= [];
gdjs.Level2Code.GDPlatform1Objects1= [];
gdjs.Level2Code.GDPlatform1Objects2= [];
gdjs.Level2Code.GDPlatform1Objects3= [];
gdjs.Level2Code.GDPlatform1Objects4= [];
gdjs.Level2Code.GDPlatform1Objects5= [];
gdjs.Level2Code.GDPlatform2Objects1= [];
gdjs.Level2Code.GDPlatform2Objects2= [];
gdjs.Level2Code.GDPlatform2Objects3= [];
gdjs.Level2Code.GDPlatform2Objects4= [];
gdjs.Level2Code.GDPlatform2Objects5= [];
gdjs.Level2Code.GDPlatform3Objects1= [];
gdjs.Level2Code.GDPlatform3Objects2= [];
gdjs.Level2Code.GDPlatform3Objects3= [];
gdjs.Level2Code.GDPlatform3Objects4= [];
gdjs.Level2Code.GDPlatform3Objects5= [];
gdjs.Level2Code.GDPlatform4Objects1= [];
gdjs.Level2Code.GDPlatform4Objects2= [];
gdjs.Level2Code.GDPlatform4Objects3= [];
gdjs.Level2Code.GDPlatform4Objects4= [];
gdjs.Level2Code.GDPlatform4Objects5= [];
gdjs.Level2Code.GDPortalObjects1= [];
gdjs.Level2Code.GDPortalObjects2= [];
gdjs.Level2Code.GDPortalObjects3= [];
gdjs.Level2Code.GDPortalObjects4= [];
gdjs.Level2Code.GDPortalObjects5= [];
gdjs.Level2Code.GDCheckpointObjects1= [];
gdjs.Level2Code.GDCheckpointObjects2= [];
gdjs.Level2Code.GDCheckpointObjects3= [];
gdjs.Level2Code.GDCheckpointObjects4= [];
gdjs.Level2Code.GDCheckpointObjects5= [];
gdjs.Level2Code.GDLadderObjects1= [];
gdjs.Level2Code.GDLadderObjects2= [];
gdjs.Level2Code.GDLadderObjects3= [];
gdjs.Level2Code.GDLadderObjects4= [];
gdjs.Level2Code.GDLadderObjects5= [];
gdjs.Level2Code.GDMonsterObjects1= [];
gdjs.Level2Code.GDMonsterObjects2= [];
gdjs.Level2Code.GDMonsterObjects3= [];
gdjs.Level2Code.GDMonsterObjects4= [];
gdjs.Level2Code.GDMonsterObjects5= [];
gdjs.Level2Code.GDFlyObjects1= [];
gdjs.Level2Code.GDFlyObjects2= [];
gdjs.Level2Code.GDFlyObjects3= [];
gdjs.Level2Code.GDFlyObjects4= [];
gdjs.Level2Code.GDFlyObjects5= [];
gdjs.Level2Code.GDCoinObjects1= [];
gdjs.Level2Code.GDCoinObjects2= [];
gdjs.Level2Code.GDCoinObjects3= [];
gdjs.Level2Code.GDCoinObjects4= [];
gdjs.Level2Code.GDCoinObjects5= [];
gdjs.Level2Code.GDMonsterParticlesObjects1= [];
gdjs.Level2Code.GDMonsterParticlesObjects2= [];
gdjs.Level2Code.GDMonsterParticlesObjects3= [];
gdjs.Level2Code.GDMonsterParticlesObjects4= [];
gdjs.Level2Code.GDMonsterParticlesObjects5= [];
gdjs.Level2Code.GDCoinParticlesObjects1= [];
gdjs.Level2Code.GDCoinParticlesObjects2= [];
gdjs.Level2Code.GDCoinParticlesObjects3= [];
gdjs.Level2Code.GDCoinParticlesObjects4= [];
gdjs.Level2Code.GDCoinParticlesObjects5= [];
gdjs.Level2Code.GDDoorParticlesObjects1= [];
gdjs.Level2Code.GDDoorParticlesObjects2= [];
gdjs.Level2Code.GDDoorParticlesObjects3= [];
gdjs.Level2Code.GDDoorParticlesObjects4= [];
gdjs.Level2Code.GDDoorParticlesObjects5= [];
gdjs.Level2Code.GDDustParticleObjects1= [];
gdjs.Level2Code.GDDustParticleObjects2= [];
gdjs.Level2Code.GDDustParticleObjects3= [];
gdjs.Level2Code.GDDustParticleObjects4= [];
gdjs.Level2Code.GDDustParticleObjects5= [];
gdjs.Level2Code.GDCloudsObjects1= [];
gdjs.Level2Code.GDCloudsObjects2= [];
gdjs.Level2Code.GDCloudsObjects3= [];
gdjs.Level2Code.GDCloudsObjects4= [];
gdjs.Level2Code.GDCloudsObjects5= [];
gdjs.Level2Code.GDScoreTextObjects1= [];
gdjs.Level2Code.GDScoreTextObjects2= [];
gdjs.Level2Code.GDScoreTextObjects3= [];
gdjs.Level2Code.GDScoreTextObjects4= [];
gdjs.Level2Code.GDScoreTextObjects5= [];
gdjs.Level2Code.GDBackgroundPlantsObjects1= [];
gdjs.Level2Code.GDBackgroundPlantsObjects2= [];
gdjs.Level2Code.GDBackgroundPlantsObjects3= [];
gdjs.Level2Code.GDBackgroundPlantsObjects4= [];
gdjs.Level2Code.GDBackgroundPlantsObjects5= [];
gdjs.Level2Code.GDLeftBoundaryObjects1= [];
gdjs.Level2Code.GDLeftBoundaryObjects2= [];
gdjs.Level2Code.GDLeftBoundaryObjects3= [];
gdjs.Level2Code.GDLeftBoundaryObjects4= [];
gdjs.Level2Code.GDLeftBoundaryObjects5= [];
gdjs.Level2Code.GDRightBoundaryObjects1= [];
gdjs.Level2Code.GDRightBoundaryObjects2= [];
gdjs.Level2Code.GDRightBoundaryObjects3= [];
gdjs.Level2Code.GDRightBoundaryObjects4= [];
gdjs.Level2Code.GDRightBoundaryObjects5= [];
gdjs.Level2Code.GDTopBoundaryObjects1= [];
gdjs.Level2Code.GDTopBoundaryObjects2= [];
gdjs.Level2Code.GDTopBoundaryObjects3= [];
gdjs.Level2Code.GDTopBoundaryObjects4= [];
gdjs.Level2Code.GDTopBoundaryObjects5= [];
gdjs.Level2Code.GDBottomBoundaryObjects1= [];
gdjs.Level2Code.GDBottomBoundaryObjects2= [];
gdjs.Level2Code.GDBottomBoundaryObjects3= [];
gdjs.Level2Code.GDBottomBoundaryObjects4= [];
gdjs.Level2Code.GDBottomBoundaryObjects5= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects1= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects2= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects3= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects4= [];
gdjs.Level2Code.GDBoundaryJumpThroughObjects5= [];
gdjs.Level2Code.GDMoonObjects1= [];
gdjs.Level2Code.GDMoonObjects2= [];
gdjs.Level2Code.GDMoonObjects3= [];
gdjs.Level2Code.GDMoonObjects4= [];
gdjs.Level2Code.GDMoonObjects5= [];
gdjs.Level2Code.GDEndScreenBackgroundObjects1= [];
gdjs.Level2Code.GDEndScreenBackgroundObjects2= [];
gdjs.Level2Code.GDEndScreenBackgroundObjects3= [];
gdjs.Level2Code.GDEndScreenBackgroundObjects4= [];
gdjs.Level2Code.GDEndScreenBackgroundObjects5= [];
gdjs.Level2Code.GDEndScreenHeaderObjects1= [];
gdjs.Level2Code.GDEndScreenHeaderObjects2= [];
gdjs.Level2Code.GDEndScreenHeaderObjects3= [];
gdjs.Level2Code.GDEndScreenHeaderObjects4= [];
gdjs.Level2Code.GDEndScreenHeaderObjects5= [];
gdjs.Level2Code.GDEndScreenSubHeaderObjects1= [];
gdjs.Level2Code.GDEndScreenSubHeaderObjects2= [];
gdjs.Level2Code.GDEndScreenSubHeaderObjects3= [];
gdjs.Level2Code.GDEndScreenSubHeaderObjects4= [];
gdjs.Level2Code.GDEndScreenSubHeaderObjects5= [];
gdjs.Level2Code.GDEndScreenBestTextObjects1= [];
gdjs.Level2Code.GDEndScreenBestTextObjects2= [];
gdjs.Level2Code.GDEndScreenBestTextObjects3= [];
gdjs.Level2Code.GDEndScreenBestTextObjects4= [];
gdjs.Level2Code.GDEndScreenBestTextObjects5= [];
gdjs.Level2Code.GDEndScreenChallengeTextObjects1= [];
gdjs.Level2Code.GDEndScreenChallengeTextObjects2= [];
gdjs.Level2Code.GDEndScreenChallengeTextObjects3= [];
gdjs.Level2Code.GDEndScreenChallengeTextObjects4= [];
gdjs.Level2Code.GDEndScreenChallengeTextObjects5= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects1= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects2= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects3= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects4= [];
gdjs.Level2Code.GDEndScreenRetryTextObjects5= [];
gdjs.Level2Code.GDRetryButtonObjects1= [];
gdjs.Level2Code.GDRetryButtonObjects2= [];
gdjs.Level2Code.GDRetryButtonObjects3= [];
gdjs.Level2Code.GDRetryButtonObjects4= [];
gdjs.Level2Code.GDRetryButtonObjects5= [];
gdjs.Level2Code.GDJoystickObjects1= [];
gdjs.Level2Code.GDJoystickObjects2= [];
gdjs.Level2Code.GDJoystickObjects3= [];
gdjs.Level2Code.GDJoystickObjects4= [];
gdjs.Level2Code.GDJoystickObjects5= [];
gdjs.Level2Code.GDJumpButtonObjects1= [];
gdjs.Level2Code.GDJumpButtonObjects2= [];
gdjs.Level2Code.GDJumpButtonObjects3= [];
gdjs.Level2Code.GDJumpButtonObjects4= [];
gdjs.Level2Code.GDJumpButtonObjects5= [];


gdjs.Level2Code.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level2Code.GDJumpButtonObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDJumpButtonObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDJumpButtonObjects3[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDJumpButtonObjects3[k] = gdjs.Level2Code.GDJumpButtonObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDJumpButtonObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(22584852);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDJumpButtonObjects3 */
{for(var i = 0, len = gdjs.Level2Code.GDJumpButtonObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDJumpButtonObjects3[i].setColor("74;74;74");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level2Code.GDJumpButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDJumpButtonObjects2.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDJumpButtonObjects2[i].getBehavior("MultitouchButton").IsPressed((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDJumpButtonObjects2[k] = gdjs.Level2Code.GDJumpButtonObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDJumpButtonObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(20118524);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDJumpButtonObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDJumpButtonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDJumpButtonObjects2[i].setColor("255;255;255");
}
}}

}


};gdjs.Level2Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList0(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Joystick"), gdjs.Level2Code.GDJoystickObjects1);
gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.Level2Code.GDJumpButtonObjects1);
{for(var i = 0, len = gdjs.Level2Code.GDJumpButtonObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDJumpButtonObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.Level2Code.GDJoystickObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDJoystickObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level2Code.eventsList2 = function(runtimeScene) {

{



}


{


gdjs.Level2Code.eventsList1(runtimeScene);
}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDDustParticleObjects2Objects = Hashtable.newFrom({"DustParticle": gdjs.Level2Code.GDDustParticleObjects2});
gdjs.Level2Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isJumping() ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(14812508);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "jump.mp3", false, 50, 1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Player__IsSteppingOnFloor.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(21188932);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.Level2Code.GDDustParticleObjects2.length = 0;

{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "assets/audio/grass.mp3", 1, false, 20, gdjs.randomFloatInRange(0.7, 1.2));
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDDustParticleObjects2Objects, (( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getAABBCenterX()), (( gdjs.Level2Code.GDPlayerObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects2[0].getAABBBottom()), "");
}{for(var i = 0, len = gdjs.Level2Code.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDDustParticleObjects2[i].setZOrder(-(1));
}
}{for(var i = 0, len = gdjs.Level2Code.GDDustParticleObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDDustParticleObjects2[i].setAngle(270);
}
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects2Objects = Hashtable.newFrom({"Checkpoint": gdjs.Level2Code.GDCheckpointObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects3Objects = Hashtable.newFrom({"Checkpoint": gdjs.Level2Code.GDCheckpointObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.eventsList4 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level2Code.GDCheckpointObjects2, gdjs.Level2Code.GDCheckpointObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects3Objects);
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDCheckpointObjects3 */
{for(var i = 0, len = gdjs.Level2Code.GDCheckpointObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDCheckpointObjects3[i].getBehavior("Animation").setAnimationName("InActive");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level2Code.GDCheckpointObjects2 */
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, (( gdjs.Level2Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCheckpointObjects2[0].getPointX("")), (( gdjs.Level2Code.GDCheckpointObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCheckpointObjects2[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.Level2Code.GDCheckpointObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCheckpointObjects2[i].getBehavior("Animation").setAnimationName("Activate");
}
}}

}


};gdjs.Level2Code.eventsList5 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects3);
{gdjs.evtsExt__Checkpoints__SaveCheckpoint.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects, (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getPointX("")), (( gdjs.Level2Code.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.Level2Code.GDPlayerObjects3[0].getPointY("")), "Checkpoint", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Checkpoint"), gdjs.Level2Code.GDCheckpointObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCheckpointObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDCheckpointObjects2.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDCheckpointObjects2[i].getBehavior("Animation").getAnimationName() == "Activate") ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDCheckpointObjects2[k] = gdjs.Level2Code.GDCheckpointObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDCheckpointObjects2.length = k;
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "checkpoint.mp3", false, 50, 1);
}
{ //Subevents
gdjs.Level2Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinObjects2Objects = Hashtable.newFrom({"Coin": gdjs.Level2Code.GDCoinObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinParticlesObjects2Objects = Hashtable.newFrom({"CoinParticles": gdjs.Level2Code.GDCoinParticlesObjects2});
gdjs.Level2Code.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Coin"), gdjs.Level2Code.GDCoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDCoinObjects2 */
gdjs.Level2Code.GDCoinParticlesObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDCoinParticlesObjects2Objects, (( gdjs.Level2Code.GDCoinObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCoinObjects2[0].getCenterXInScene()), (( gdjs.Level2Code.GDCoinObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDCoinObjects2[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.Level2Code.GDCoinObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCoinObjects2[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(100);
}{gdjs.evtTools.sound.playSound(runtimeScene, "coin.mp3", false, 50, 1);
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.eventsList7 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects1[i].getY() > gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects1[k] = gdjs.Level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level2Code.eventsList8 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList3(runtimeScene);
}


{


gdjs.Level2Code.eventsList5(runtimeScene);
}


{


gdjs.Level2Code.eventsList6(runtimeScene);
}


{


gdjs.Level2Code.eventsList7(runtimeScene);
}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.Level2Code.GDFlyObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects = Hashtable.newFrom({"Fly": gdjs.Level2Code.GDFlyObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects3Objects = Hashtable.newFrom({"Fly": gdjs.Level2Code.GDFlyObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects3});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.eventsList9 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects2, gdjs.Level2Code.GDPlayerObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects3[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects3[k] = gdjs.Level2Code.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level2Code.GDFlyObjects2, gdjs.Level2Code.GDFlyObjects3);

/* Reuse gdjs.Level2Code.GDPlayerObjects3 */
{gdjs.evtsExt__Enemy__TriggerFlyDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects3Objects, "RectangleMovement", "ShakeObject_PositionAngle", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects3Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.Level2Code.GDPlayerObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level2Code.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level2Code.GDFlyObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtsExt__Enemy__IsFlyDead.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDFlyObjects2Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.eventsList11 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.Level2Code.GDBackgroundPlantsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Fly"), gdjs.Level2Code.GDFlyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDFlyObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDFlyObjects1[i].getY() > (( gdjs.Level2Code.GDBackgroundPlantsObjects1.length === 0 ) ? 0 :gdjs.Level2Code.GDBackgroundPlantsObjects1[0].getAABBBottom()) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDFlyObjects1[k] = gdjs.Level2Code.GDFlyObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDFlyObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDFlyObjects1 */
{for(var i = 0, len = gdjs.Level2Code.GDFlyObjects1.length ;i < len;++i) {
    gdjs.Level2Code.GDFlyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.Level2Code.eventsList12 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList10(runtimeScene);
}


{


gdjs.Level2Code.eventsList11(runtimeScene);
}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterObjects1Objects = Hashtable.newFrom({"Monster": gdjs.Level2Code.GDMonsterObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterParticlesObjects2Objects = Hashtable.newFrom({"MonsterParticles": gdjs.Level2Code.GDMonsterParticlesObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.eventsList13 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDPlayerObjects2[i].getBehavior("PlatformerObject").isFalling() ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects2[k] = gdjs.Level2Code.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level2Code.GDMonsterObjects1, gdjs.Level2Code.GDMonsterObjects2);

/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
gdjs.Level2Code.GDMonsterParticlesObjects2.length = 0;

{for(var i = 0, len = gdjs.Level2Code.GDMonsterObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDMonsterObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterParticlesObjects2Objects, (( gdjs.Level2Code.GDMonsterObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDMonsterObjects2[0].getCenterXInScene()), (( gdjs.Level2Code.GDMonsterObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDMonsterObjects2[0].getCenterYInScene()), "");
}{gdjs.evtsExt__Player__Bounce.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "PlatformerObject", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{runtimeScene.getScene().getVariables().getFromIndex(0).add(50);
}}

}


{

/* Reuse gdjs.Level2Code.GDPlayerObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDPlayerObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDPlayerObjects1[k] = gdjs.Level2Code.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Level2Code.GDPlayerObjects1 */
{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level2Code.eventsList14 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.Level2Code.GDMonsterObjects1, gdjs.Level2Code.GDMonsterObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDMonsterObjects2.length;i<l;++i) {
    if ( gdjs.Level2Code.GDMonsterObjects2[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDMonsterObjects2[k] = gdjs.Level2Code.GDMonsterObjects2[i];
        ++k;
    }
}
gdjs.Level2Code.GDMonsterObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.Level2Code.GDPlayerObjects1, gdjs.Level2Code.GDPlayerObjects2);

{gdjs.evtsExt__Player__TriggerDeath.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

/* Reuse gdjs.Level2Code.GDMonsterObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDMonsterObjects1.length;i<l;++i) {
    if ( !(gdjs.Level2Code.GDMonsterObjects1[i].getBehavior("MonsterEnemy").IsOnFire((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDMonsterObjects1[k] = gdjs.Level2Code.GDMonsterObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDMonsterObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.eventsList15 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Monster"), gdjs.Level2Code.GDMonsterObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDMonsterObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList14(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.eventsList16 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList15(runtimeScene);
}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.Level2Code.GDPortalObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects2});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects = Hashtable.newFrom({"Portal": gdjs.Level2Code.GDPortalObjects2});
gdjs.Level2Code.eventsList17 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.Level2Code.GDPlayerObjects2 */
/* Reuse gdjs.Level2Code.GDPortalObjects2 */
{for(var i = 0, len = gdjs.Level2Code.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDPlayerObjects2[i].activateBehavior("PlatformerObject", false);
}
}{gdjs.evtsExt__Player__AnimateFallingIntoPortal.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, "Tween", gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level2Code.eventsList18 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList17(runtimeScene);
}


};gdjs.Level2Code.eventsList19 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.Level2Code.GDEndScreenSubHeaderObjects4);
{for(var i = 0, len = gdjs.Level2Code.GDEndScreenSubHeaderObjects4.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenSubHeaderObjects4[i].getBehavior("Text").setText("You got " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)) + " points!");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) < 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.Level2Code.GDEndScreenBestTextObjects4);
{for(var i = 0, len = gdjs.Level2Code.GDEndScreenBestTextObjects4.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenBestTextObjects4[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) >= 950;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.Level2Code.GDEndScreenChallengeTextObjects3);
{for(var i = 0, len = gdjs.Level2Code.GDEndScreenChallengeTextObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenChallengeTextObjects3[i].hide();
}
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDEndScreenBackgroundObjects2Objects = Hashtable.newFrom({"EndScreenBackground": gdjs.Level2Code.GDEndScreenBackgroundObjects2});
gdjs.Level2Code.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12554948);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList19(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.Level2Code.GDEndScreenBackgroundObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenBestText"), gdjs.Level2Code.GDEndScreenBestTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenChallengeText"), gdjs.Level2Code.GDEndScreenChallengeTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenHeader"), gdjs.Level2Code.GDEndScreenHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenRetryText"), gdjs.Level2Code.GDEndScreenRetryTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("EndScreenSubHeader"), gdjs.Level2Code.GDEndScreenSubHeaderObjects2);
gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.Level2Code.GDRetryButtonObjects2);
{gdjs.evtsExt__UserInterface__StretchToFillScreen.func(runtimeScene, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDEndScreenBackgroundObjects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.Level2Code.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenBackgroundObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.Level2Code.GDEndScreenHeaderObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.Level2Code.GDEndScreenSubHeaderObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenSubHeaderObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.Level2Code.GDEndScreenBestTextObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenBestTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.Level2Code.GDEndScreenChallengeTextObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenChallengeTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.Level2Code.GDEndScreenRetryTextObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenRetryTextObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
for(var i = 0, len = gdjs.Level2Code.GDRetryButtonObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDRetryButtonObjects2[i].setCenterXInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "EndScreen", 0));
}
}}

}


};gdjs.Level2Code.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("RetryButton"), gdjs.Level2Code.GDRetryButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Level2Code.GDRetryButtonObjects1.length;i<l;++i) {
    if ( gdjs.Level2Code.GDRetryButtonObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.Level2Code.GDRetryButtonObjects1[k] = gdjs.Level2Code.GDRetryButtonObjects1[i];
        ++k;
    }
}
gdjs.Level2Code.GDRetryButtonObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}}

}


};gdjs.Level2Code.eventsList22 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList20(runtimeScene);
}


{


gdjs.Level2Code.eventsList21(runtimeScene);
}


};gdjs.Level2Code.eventsList23 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("EndScreenBackground"), gdjs.Level2Code.GDEndScreenBackgroundObjects2);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndScreen");
}{for(var i = 0, len = gdjs.Level2Code.GDEndScreenBackgroundObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDEndScreenBackgroundObjects2[i].getBehavior("Opacity").setOpacity(130);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level2Code.GDPortalObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects2Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12827612);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndScreen");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level3", true);
}
{ //Subevents
gdjs.Level2Code.eventsList18(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndScreen");
if (isConditionTrue_0) {

{ //Subevents
gdjs.Level2Code.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.Level2Code.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("BoundaryJumpThrough"), gdjs.Level2Code.GDBoundaryJumpThroughObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.Level2Code.GDLeftBoundaryObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.Level2Code.GDRightBoundaryObjects3);
{for(var i = 0, len = gdjs.Level2Code.GDLeftBoundaryObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDLeftBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.Level2Code.GDRightBoundaryObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDRightBoundaryObjects3[i].hide();
}
for(var i = 0, len = gdjs.Level2Code.GDBoundaryJumpThroughObjects3.length ;i < len;++i) {
    gdjs.Level2Code.GDBoundaryJumpThroughObjects3[i].hide();
}
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BottomBoundary"), gdjs.Level2Code.GDBottomBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftBoundary"), gdjs.Level2Code.GDLeftBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightBoundary"), gdjs.Level2Code.GDRightBoundaryObjects2);
gdjs.copyArray(runtimeScene.getObjects("TopBoundary"), gdjs.Level2Code.GDTopBoundaryObjects2);
{gdjs.evtTools.camera.clampCamera(runtimeScene, (( gdjs.Level2Code.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDLeftBoundaryObjects2[0].getPointX("")) + (( gdjs.Level2Code.GDLeftBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDLeftBoundaryObjects2[0].getWidth()), (( gdjs.Level2Code.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDTopBoundaryObjects2[0].getPointY("")) + (( gdjs.Level2Code.GDTopBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDTopBoundaryObjects2[0].getHeight()), (( gdjs.Level2Code.GDRightBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDRightBoundaryObjects2[0].getPointX("")), (( gdjs.Level2Code.GDBottomBoundaryObjects2.length === 0 ) ? 0 :gdjs.Level2Code.GDBottomBoundaryObjects2[0].getPointY("")), "", 0);
}}

}


};gdjs.Level2Code.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSound(runtimeScene, "crickets.aac", true, 30, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("BackgroundPlants"), gdjs.Level2Code.GDBackgroundPlantsObjects2);
gdjs.copyArray(runtimeScene.getObjects("Clouds"), gdjs.Level2Code.GDCloudsObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDBackgroundPlantsObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDBackgroundPlantsObjects2[i].getBehavior("Resizable").setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Level2Code.GDBackgroundPlantsObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDBackgroundPlantsObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) / 3 + 780);
}
}{for(var i = 0, len = gdjs.Level2Code.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCloudsObjects2[i].setX(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Level2Code.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCloudsObjects2[i].getBehavior("Resizable").setWidth(gdjs.evtTools.camera.getCameraWidth(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.Level2Code.GDCloudsObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDCloudsObjects2[i].setXOffset(gdjs.evtTools.camera.getCameraBorderLeft(runtimeScene, "", 0) * 1.2);
}
}}

}


};gdjs.Level2Code.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.Level2Code.GDScoreTextObjects2);
{for(var i = 0, len = gdjs.Level2Code.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.Level2Code.GDScoreTextObjects2[i].getBehavior("Text").setText("Score: " + gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(0)));
}
}}

}


};gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects1Objects = Hashtable.newFrom({"Portal": gdjs.Level2Code.GDPortalObjects1});
gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects = Hashtable.newFrom({"Player": gdjs.Level2Code.GDPlayerObjects1});
gdjs.Level2Code.eventsList27 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "door.aac", 0, true, 100, 1);
}}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.Level2Code.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("Portal"), gdjs.Level2Code.GDPortalObjects1);
{gdjs.evtsExt__VolumeFalloff__SetVolumeFalloff.func(runtimeScene, 0, "Sound", gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPortalObjects1Objects, gdjs.Level2Code.mapOfGDgdjs_9546Level2Code_9546GDPlayerObjects1Objects, 0, 20, 750, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.Level2Code.eventsList28 = function(runtimeScene) {

{


gdjs.Level2Code.eventsList24(runtimeScene);
}


{


gdjs.Level2Code.eventsList25(runtimeScene);
}


{


gdjs.Level2Code.eventsList26(runtimeScene);
}


{


gdjs.Level2Code.eventsList27(runtimeScene);
}


};gdjs.Level2Code.eventsList29 = function(runtimeScene) {

{



}


{


gdjs.Level2Code.eventsList2(runtimeScene);
}


{


gdjs.Level2Code.eventsList8(runtimeScene);
}


{


gdjs.Level2Code.eventsList12(runtimeScene);
}


{


gdjs.Level2Code.eventsList16(runtimeScene);
}


{


gdjs.Level2Code.eventsList23(runtimeScene);
}


{


gdjs.Level2Code.eventsList28(runtimeScene);
}


};

gdjs.Level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level2Code.GDPlayerObjects1.length = 0;
gdjs.Level2Code.GDPlayerObjects2.length = 0;
gdjs.Level2Code.GDPlayerObjects3.length = 0;
gdjs.Level2Code.GDPlayerObjects4.length = 0;
gdjs.Level2Code.GDPlayerObjects5.length = 0;
gdjs.Level2Code.GDPlatform1Objects1.length = 0;
gdjs.Level2Code.GDPlatform1Objects2.length = 0;
gdjs.Level2Code.GDPlatform1Objects3.length = 0;
gdjs.Level2Code.GDPlatform1Objects4.length = 0;
gdjs.Level2Code.GDPlatform1Objects5.length = 0;
gdjs.Level2Code.GDPlatform2Objects1.length = 0;
gdjs.Level2Code.GDPlatform2Objects2.length = 0;
gdjs.Level2Code.GDPlatform2Objects3.length = 0;
gdjs.Level2Code.GDPlatform2Objects4.length = 0;
gdjs.Level2Code.GDPlatform2Objects5.length = 0;
gdjs.Level2Code.GDPlatform3Objects1.length = 0;
gdjs.Level2Code.GDPlatform3Objects2.length = 0;
gdjs.Level2Code.GDPlatform3Objects3.length = 0;
gdjs.Level2Code.GDPlatform3Objects4.length = 0;
gdjs.Level2Code.GDPlatform3Objects5.length = 0;
gdjs.Level2Code.GDPlatform4Objects1.length = 0;
gdjs.Level2Code.GDPlatform4Objects2.length = 0;
gdjs.Level2Code.GDPlatform4Objects3.length = 0;
gdjs.Level2Code.GDPlatform4Objects4.length = 0;
gdjs.Level2Code.GDPlatform4Objects5.length = 0;
gdjs.Level2Code.GDPortalObjects1.length = 0;
gdjs.Level2Code.GDPortalObjects2.length = 0;
gdjs.Level2Code.GDPortalObjects3.length = 0;
gdjs.Level2Code.GDPortalObjects4.length = 0;
gdjs.Level2Code.GDPortalObjects5.length = 0;
gdjs.Level2Code.GDCheckpointObjects1.length = 0;
gdjs.Level2Code.GDCheckpointObjects2.length = 0;
gdjs.Level2Code.GDCheckpointObjects3.length = 0;
gdjs.Level2Code.GDCheckpointObjects4.length = 0;
gdjs.Level2Code.GDCheckpointObjects5.length = 0;
gdjs.Level2Code.GDLadderObjects1.length = 0;
gdjs.Level2Code.GDLadderObjects2.length = 0;
gdjs.Level2Code.GDLadderObjects3.length = 0;
gdjs.Level2Code.GDLadderObjects4.length = 0;
gdjs.Level2Code.GDLadderObjects5.length = 0;
gdjs.Level2Code.GDMonsterObjects1.length = 0;
gdjs.Level2Code.GDMonsterObjects2.length = 0;
gdjs.Level2Code.GDMonsterObjects3.length = 0;
gdjs.Level2Code.GDMonsterObjects4.length = 0;
gdjs.Level2Code.GDMonsterObjects5.length = 0;
gdjs.Level2Code.GDFlyObjects1.length = 0;
gdjs.Level2Code.GDFlyObjects2.length = 0;
gdjs.Level2Code.GDFlyObjects3.length = 0;
gdjs.Level2Code.GDFlyObjects4.length = 0;
gdjs.Level2Code.GDFlyObjects5.length = 0;
gdjs.Level2Code.GDCoinObjects1.length = 0;
gdjs.Level2Code.GDCoinObjects2.length = 0;
gdjs.Level2Code.GDCoinObjects3.length = 0;
gdjs.Level2Code.GDCoinObjects4.length = 0;
gdjs.Level2Code.GDCoinObjects5.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects1.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects2.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects3.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects4.length = 0;
gdjs.Level2Code.GDMonsterParticlesObjects5.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects1.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects2.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects3.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects4.length = 0;
gdjs.Level2Code.GDCoinParticlesObjects5.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects1.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects2.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects3.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects4.length = 0;
gdjs.Level2Code.GDDoorParticlesObjects5.length = 0;
gdjs.Level2Code.GDDustParticleObjects1.length = 0;
gdjs.Level2Code.GDDustParticleObjects2.length = 0;
gdjs.Level2Code.GDDustParticleObjects3.length = 0;
gdjs.Level2Code.GDDustParticleObjects4.length = 0;
gdjs.Level2Code.GDDustParticleObjects5.length = 0;
gdjs.Level2Code.GDCloudsObjects1.length = 0;
gdjs.Level2Code.GDCloudsObjects2.length = 0;
gdjs.Level2Code.GDCloudsObjects3.length = 0;
gdjs.Level2Code.GDCloudsObjects4.length = 0;
gdjs.Level2Code.GDCloudsObjects5.length = 0;
gdjs.Level2Code.GDScoreTextObjects1.length = 0;
gdjs.Level2Code.GDScoreTextObjects2.length = 0;
gdjs.Level2Code.GDScoreTextObjects3.length = 0;
gdjs.Level2Code.GDScoreTextObjects4.length = 0;
gdjs.Level2Code.GDScoreTextObjects5.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects1.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects2.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects3.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects4.length = 0;
gdjs.Level2Code.GDBackgroundPlantsObjects5.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects1.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects2.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects3.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects4.length = 0;
gdjs.Level2Code.GDLeftBoundaryObjects5.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects1.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects2.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects3.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects4.length = 0;
gdjs.Level2Code.GDRightBoundaryObjects5.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects1.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects2.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects3.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects4.length = 0;
gdjs.Level2Code.GDTopBoundaryObjects5.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects1.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects2.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects3.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects4.length = 0;
gdjs.Level2Code.GDBottomBoundaryObjects5.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects1.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects2.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects3.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects4.length = 0;
gdjs.Level2Code.GDBoundaryJumpThroughObjects5.length = 0;
gdjs.Level2Code.GDMoonObjects1.length = 0;
gdjs.Level2Code.GDMoonObjects2.length = 0;
gdjs.Level2Code.GDMoonObjects3.length = 0;
gdjs.Level2Code.GDMoonObjects4.length = 0;
gdjs.Level2Code.GDMoonObjects5.length = 0;
gdjs.Level2Code.GDEndScreenBackgroundObjects1.length = 0;
gdjs.Level2Code.GDEndScreenBackgroundObjects2.length = 0;
gdjs.Level2Code.GDEndScreenBackgroundObjects3.length = 0;
gdjs.Level2Code.GDEndScreenBackgroundObjects4.length = 0;
gdjs.Level2Code.GDEndScreenBackgroundObjects5.length = 0;
gdjs.Level2Code.GDEndScreenHeaderObjects1.length = 0;
gdjs.Level2Code.GDEndScreenHeaderObjects2.length = 0;
gdjs.Level2Code.GDEndScreenHeaderObjects3.length = 0;
gdjs.Level2Code.GDEndScreenHeaderObjects4.length = 0;
gdjs.Level2Code.GDEndScreenHeaderObjects5.length = 0;
gdjs.Level2Code.GDEndScreenSubHeaderObjects1.length = 0;
gdjs.Level2Code.GDEndScreenSubHeaderObjects2.length = 0;
gdjs.Level2Code.GDEndScreenSubHeaderObjects3.length = 0;
gdjs.Level2Code.GDEndScreenSubHeaderObjects4.length = 0;
gdjs.Level2Code.GDEndScreenSubHeaderObjects5.length = 0;
gdjs.Level2Code.GDEndScreenBestTextObjects1.length = 0;
gdjs.Level2Code.GDEndScreenBestTextObjects2.length = 0;
gdjs.Level2Code.GDEndScreenBestTextObjects3.length = 0;
gdjs.Level2Code.GDEndScreenBestTextObjects4.length = 0;
gdjs.Level2Code.GDEndScreenBestTextObjects5.length = 0;
gdjs.Level2Code.GDEndScreenChallengeTextObjects1.length = 0;
gdjs.Level2Code.GDEndScreenChallengeTextObjects2.length = 0;
gdjs.Level2Code.GDEndScreenChallengeTextObjects3.length = 0;
gdjs.Level2Code.GDEndScreenChallengeTextObjects4.length = 0;
gdjs.Level2Code.GDEndScreenChallengeTextObjects5.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects1.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects2.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects3.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects4.length = 0;
gdjs.Level2Code.GDEndScreenRetryTextObjects5.length = 0;
gdjs.Level2Code.GDRetryButtonObjects1.length = 0;
gdjs.Level2Code.GDRetryButtonObjects2.length = 0;
gdjs.Level2Code.GDRetryButtonObjects3.length = 0;
gdjs.Level2Code.GDRetryButtonObjects4.length = 0;
gdjs.Level2Code.GDRetryButtonObjects5.length = 0;
gdjs.Level2Code.GDJoystickObjects1.length = 0;
gdjs.Level2Code.GDJoystickObjects2.length = 0;
gdjs.Level2Code.GDJoystickObjects3.length = 0;
gdjs.Level2Code.GDJoystickObjects4.length = 0;
gdjs.Level2Code.GDJoystickObjects5.length = 0;
gdjs.Level2Code.GDJumpButtonObjects1.length = 0;
gdjs.Level2Code.GDJumpButtonObjects2.length = 0;
gdjs.Level2Code.GDJumpButtonObjects3.length = 0;
gdjs.Level2Code.GDJumpButtonObjects4.length = 0;
gdjs.Level2Code.GDJumpButtonObjects5.length = 0;

gdjs.Level2Code.eventsList29(runtimeScene);

return;

}

gdjs['Level2Code'] = gdjs.Level2Code;
